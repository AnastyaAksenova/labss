﻿Отчёт по лабораторной работе№13![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.001.png)

Аксенова Анастасия   2Июня 2022

РУДН,Москва, Россия

1/8

Отчет по лабораторнойработы №13![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.002.png)


Программав calculate.c![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.003.png)

Реализация функций калькулятора в файлеcalculate.с(Программана рис.1).

![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.004.png)

Figure 1:Программа в calculate.c

2/8
Программав calculate.c![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.005.png)

Реализация функций калькулятора в файлеcalculate.с(Программа представлена на рис.2).

![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.006.png)

Figure 2:Программа в calculate.c

3/8
Программав calculate.h![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.007.png)

Интерфейсныйфайл calculate.h,описывающий формат вызова функциикалькулятора (Скриншот 3 ).

![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.008.png)

Figure 3:Программа в calculate.h

4/8

Программавmain.c![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.009.png)

Основной файл main.c,реализующий интерфейс пользователя к калькулятору (Скриншот 4 ).

![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.010.png)

Figure 4:Программа в main.c

5/8

Работасgdb![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.011.png)

Далее с помощьюgdb выполнила отладку программы calcul (Рисунок5).

![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.012.png)

Figure 5:Работа сgdb

6/8

Выводы![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.013.png)

В ходе выполнения данной лабораторной работы я приобрелапростейшие навыки разработки, анализа, тестирования и отладки приложений в ОС типа UNIX/Linuxна примере создания на языкепрограммирования Скалькулятора с простейшими функциями.

7/8

Библиография![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.014.png)

1. Программное обеспечение GNU/Linux.Лекция9.Хранилище и  дистрибутив (Г.Курячий,МГУ)
1. Программное обеспечение GNU/Linux.Лекция 10.Минимальный набор знаний (Г.Курячий,МГУ)
1. Программное обеспечение GNU/Linux. Лекция 11.udev,DBus, PolicyKit (Г.Курячий,МГУ)

\1. Электронныйресурс:https://vunivere.ru/work23597

\1. Электронный ресурс:https://it.wikireading.ru/34160

8/8

Спасибозавнимание!![](Aspose.Words.254da240-096c-40f9-bffc-ddbcb52d2e7c.015.png)

