﻿Отчёт по лабораторной работе№14![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.001.png)

Аксенова Анастасия  2Июня 2022

РУДН,Москва, Россия

1/9

Отчет по лабораторнойработы №14![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.002.png)


Файлcommon.h![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.003.png)

Common.hпредназначен длязаголовочныхфайлов,чтобыв остальных программах ихне прописыватькаждый раз (Программарис.1).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.004.png)

Figure 1:Прграмма в файле common.h

2/9
Файлserver.c![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.005.png)

В файлserver.cдобавила циклwhile для контроля за временем работы 

сервера (алгоритм действий представлен на рис.2).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.006.png)

Figure 2:Прграмма в файле server.c

3/9
Файлserver.c![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.007.png)

В файлserver.cдобавила циклwhile для контроля за временем работы 

сервера (алгоритм действий представлен на рис.2).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.008.png)

Figure 3:Прграмма в файле server.c

4/9
Файлclient.c![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.009.png)

В файл client.cдобавила цикл, которыйотвечает за количество 

сообщений о текущемвремени (Скриншот 4 ).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.010.png)

Figure 4:Прграмма в файле client.c

5/9
Файлclient.c![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.011.png)

В файл client.cдобавила цикл, которыйотвечает за количество 

сообщений о текущемвремени (Скриншот 4 ).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.012.png)

Figure 5:Прграмма в файле client.c

6/9

РаботасMikefile![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.013.png)

Makefile(файлдля сборки) не изменяла (Рисунок6 ).

![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.014.png)

Figure 6:Прграмма в Mikefile

7/9

Выводы![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.015.png)

В ходевыполнения данной лабораторной работы я приобрела практические навыки работыс именованными каналами.

8/9

Библиография![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.016.png)

1. Программное обеспечение GNU/Linux.Лекция 10.Минимальный набор знаний (Г.Курячий,МГУ)
1. Программное обеспечение GNU/Linux. Лекция 12. Выбор дистрибутива (Г.Курячий, МГУ)
1. Электронныйресурс:https://habr.com/ru/post/122108/
1. Электронный ресурс: https://[www.opennet.ru/docs/RUS/linux_parallel/node17.html](http://www.opennet.ru/docs/RUS/linux_parallel/node17.html)

9/9

Спасибозавнимание!![](Aspose.Words.6d0acbd9-6f50-4069-9ef6-609c59cafd2e.017.png)

